CREATE TRIGGER backup_trigger
    AFTER UPDATE
    ON backup_table
    WHEN old.location = new.location
BEGIN
    UPDATE backup_table SET last_backup=(strftime('%Y-%m-%d %H:%M:%S', 'now','+3 hours')) WHERE location = new.location;
END;

